#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    tutor_pet_lib::run()
}
